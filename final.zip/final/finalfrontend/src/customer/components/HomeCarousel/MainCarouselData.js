export const MainCarouselData=[
    {
        image:"https://www.jakson.com/solar-inverter/images/slide.jpg",
        path:"/Solar Items/Solar Panels/Technology-Mono Panels"
    },
    {
        //image:"https://wallpaperaccess.com/full/1663640.jpg",
        image:"https://www.upsinverter.com/utl/wp-content/uploads/2020/07/SOLAR-PANEL.jpg",
        path:"/Solar Items/Solar Panels/Technology-Mono Panels"
    },
    {
        image:"https://spectrum.ieee.org/media-library/less-than-p-greater-than-electric-vehicle-charging-stations-in-monterey-park-calif-less-than-p-greater-than.jpg?id=32246419",
        path:"/Solar Items/Solar Panels/Technology-Mono Panels"
    },

    {
        image:"https://img.freepik.com/premium-vector/electric-scooter-charging-charge-station-electric-vehicle-concept-illustration_148087-249.jpg?w=2000",
        path:"/Solar Items/Solar Panels/Technology-Mono Panels"
    }

]

export default MainCarouselData;

